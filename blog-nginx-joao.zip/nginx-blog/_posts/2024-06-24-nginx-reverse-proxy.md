---
layout: post
title: "Como configurar Proxy Reverso com NGINX"
date: 2024-06-24
categories: nginx proxy
---

## 🌐 O que é Proxy Reverso?

Um **proxy reverso** atua como um intermediário entre o cliente (navegador) e o servidor onde a aplicação está rodando.

Ele é usado para:

- Redirecionar tráfego para serviços internos
- Esconder portas e IPs reais
- Aplicar SSL mesmo quando o backend não tem HTTPS
- Fazer balanceamento de carga

---

## ✅ Exemplo prático com NGINX

```nginx
server {
    listen 443 ssl;
    server_name app.seudominio.com;

    ssl_certificate     /caminho/cert.pem;
    ssl_certificate_key /caminho/chave.key;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Este exemplo aceita conexões HTTPS em `app.seudominio.com` e redireciona para `localhost:3000`.

---

## 🧪 Testando

```bash
sudo nginx -t
sudo systemctl restart nginx
```

Use `curl -I https://app.seudominio.com` para testar o cabeçalho de resposta.

---

## 🔒 Dica extra

Você pode usar **Let's Encrypt** com o Certbot para gerar certificados SSL gratuitos:

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx
```

---

📌 Esse post faz parte do meu blog técnico [joaomelo.github.io](https://joaomelo.github.io).
