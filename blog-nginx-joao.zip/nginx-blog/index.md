---
layout: home
title: "Blog do João Melo"
---

🚀 Bem-vindo ao meu blog técnico!

Aqui compartilho conteúdos sobre infraestrutura, cloud e boas práticas em TI.

🛠️ Primeiro post: [Como configurar Proxy Reverso com NGINX](/2024/06/24/nginx-reverse-proxy.html)
